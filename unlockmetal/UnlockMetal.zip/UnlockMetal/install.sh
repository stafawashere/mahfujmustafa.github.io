#!/bin/bash
set -euo pipefail

# Production installer. Ships beside UnlockMetal.app in the release folder and
# installs that exact build onto this machine: copy the app into /Applications,
# clear quarantine, and ad-hoc re-sign Roblox so dyld will honour the insert.
#
#    ./install.sh
#
# Nothing is downloaded and nothing is compiled - what is in the folder is what
# gets installed, so the same folder installs the same build on every Mac.

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_APP="${1:-$HERE/UnlockMetal.app}"
DESTINATION_APP="/Applications/UnlockMetal.app"
ROBLOX_APP="${ROBLOX_APP:-/Applications/Roblox.app}"
PLAYER="$ROBLOX_APP/Contents/MacOS/RobloxPlayer"

echo "UnlockMetal installer"

architecture="$(arch)"
echo "==> Architecture: $architecture"

if [[ "$architecture" != "arm64" ]]; then
   echo "error: this build is arm64 only (Apple silicon)" >&2
   exit 1
fi

if [[ ! -d "$SOURCE_APP" ]]; then
   echo "error: UnlockMetal.app not found next to this script" >&2
   exit 1
fi

if [[ ! -x "$PLAYER" ]]; then
   echo "error: Roblox is not installed at $ROBLOX_APP" >&2
   echo "       install Roblox first, then run this again" >&2
   exit 1
fi

echo "==> Installing $DESTINATION_APP"
rm -rf "$DESTINATION_APP"
cp -R "$SOURCE_APP" "$DESTINATION_APP"

# A bundle that arrived through a download or an AirDrop carries the quarantine
# flag, and Gatekeeper refuses to run an ad-hoc signed app that has it.
xattr -dr com.apple.quarantine "$DESTINATION_APP" 2>/dev/null || true
codesign -f -s - --deep "$DESTINATION_APP"

echo "==> Re-signing Roblox for injection"
ROBLOX_APP="$ROBLOX_APP" "$DESTINATION_APP/Contents/Resources/resign.sh" >/tmp/unlockmetal_install.log 2>&1 || {
   echo "error: re-signing failed, see /tmp/unlockmetal_install.log" >&2
   exit 1
}

signature="$(codesign -dvv "$PLAYER" 2>&1 | grep -i "^CodeDirectory" || true)"

if [[ "$signature" == *runtime* || "$signature" != *adhoc* ]]; then
   echo "error: Roblox is still not injectable: $signature" >&2
   exit 1
fi

echo "==> Verified: $signature"
echo
echo "Installed. Open UnlockMetal from Applications to launch the patched client."
echo "Opening Roblox normally stays vanilla. Re-run this after a Roblox update"
echo "only if the launcher ever reports it could not re-sign."
