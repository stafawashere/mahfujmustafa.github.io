#!/bin/bash
set -euo pipefail

# Shared terminal styling and the exit hold-open.
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/um_tui.sh"
um_banner "installer"

# Production installer. Ships beside UnlockMetal.app in the release folder and
# installs that exact build onto this machine: copy the app into /Applications,
# clear quarantine, and ad-hoc re-sign Roblox so dyld will honour the insert.
#
#    ./install.sh
#
# Nothing is downloaded and nothing is compiled - what is in the folder is what
# gets installed, so the same folder installs the same build on every Mac.

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DESTINATION_APP="/Applications/UnlockMetal.app"
ROBLOX_APP="${ROBLOX_APP:-/Applications/Roblox.app}"
PLAYER="$ROBLOX_APP/Contents/MacOS/RobloxPlayer"

# The app to install. In a packaged release it sits beside this script; run from
# the dev tree it is wherever the build put it. An explicit path always wins.
find_source_app() {
   local candidates=(
      "$HERE/UnlockMetal.app"
      "$HERE/../obfuscate/dist/UnlockMetal/UnlockMetal.app"
      "$HERE/../dist/UnlockMetal/UnlockMetal.app"
      "$HERE/../dist/UnlockMetal.app"
   )

   for candidate in "${candidates[@]}"; do
      if [[ -d "$candidate" ]]; then
         echo "$candidate"
         return 0
      fi
   done

   return 1
}

if [[ -n "${1:-}" ]]; then
   SOURCE_APP="$1"
else
   SOURCE_APP="$(find_source_app || true)"
fi

architecture="$(arch)"
um_step "Checking hardware"
um_detail "architecture $architecture"

if [[ "$architecture" != "arm64" ]]; then
   um_die "Apple silicon required" "this build is arm64 only"
fi

if [[ -z "$SOURCE_APP" || ! -d "$SOURCE_APP" ]]; then
   um_die "UnlockMetal.app not found" "build it first (./obfuscate/obfuscate.sh) or pass its path"
fi

if [[ ! -x "$PLAYER" ]]; then
   um_die "Roblox is not installed" "install Roblox from roblox.com, then run this again"
fi

# Roblox installs that another mod has already been through are supported, but
# they behave differently enough to be worth naming before anything is touched:
# a mod that pins the client version deletes the updater, and one that injects
# through a load command keeps loading no matter which launcher starts the game.
UPDATER="$ROBLOX_APP/Contents/MacOS/RobloxPlayerInstaller.app/Contents/MacOS/RobloxPlayerInstaller"

foreign_inserts() {
   otool -l "$PLAYER" 2>/dev/null \
      | awk '/LC_LOAD_DYLIB/ { in_cmd = 1; next } in_cmd && /name /{ print $2; in_cmd = 0 }' \
      | grep -v "^/System/\|^/usr/lib/\|^@rpath/libmimalloc" || true
}

um_step "Surveying Roblox"
inserts="$(foreign_inserts)"
is_modified=0

if [[ -n "$inserts" ]]; then
   is_modified=1

   while IFS= read -r insert; do
      [[ -n "$insert" ]] || continue
      um_detail "already injects $(basename "$insert")"
   done <<< "$inserts"
fi

if [[ ! -x "$UPDATER" ]]; then
   is_modified=1
   um_warn "Roblox's updater has been removed"
   um_detail "the client will keep asking to update and cannot do it"
   um_detail "reinstall Roblox from roblox.com for a version that can update"
fi

if [[ "$is_modified" == "1" ]]; then
   um_warn "This Roblox has been modified by another tool"
   um_detail "installing anyway - both mods will load into the same client"
else
   um_good "Stock Roblox"
fi

um_step "Installing to Applications"
rm -rf "$DESTINATION_APP"
cp -R "$SOURCE_APP" "$DESTINATION_APP"

# A bundle that arrived through a download or an AirDrop carries quarantine and
# other extended attributes; Gatekeeper refuses to run an ad-hoc signed app that
# still has quarantine, and codesign refuses to seal a bundle carrying any xattr
# detritus, so clear them all before signing.
xattr -cr "$DESTINATION_APP" 2>/dev/null || true
codesign -f -s - --deep "$DESTINATION_APP" >/tmp/unlockmetal_install.log 2>&1 \
   || um_die "could not sign the app" "see /tmp/unlockmetal_install.log"

if [[ "$is_modified" == "1" ]]; then
   # Riding along with the other mod: patch a weak load command into RobloxPlayer
   # so UnlockMetal loads on every launch, whoever starts the game, against
   # whatever client version the mod is running. This re-signs as part of the
   # step, so the plain re-sign below is skipped.
   um_step "Injecting into the modified Roblox"
   ROBLOX_APP="$ROBLOX_APP" "$DESTINATION_APP/Contents/Resources/inject.sh" >/tmp/unlockmetal_install.log 2>&1 \
      || um_die "injection failed" "see /tmp/unlockmetal_install.log"
else
   um_step "Preparing Roblox for injection"
   ROBLOX_APP="$ROBLOX_APP" "$DESTINATION_APP/Contents/Resources/resign.sh" >/tmp/unlockmetal_install.log 2>&1 \
      || um_die "re-signing failed" "see /tmp/unlockmetal_install.log"
fi

signature="$(codesign -dvv "$PLAYER" 2>&1 | grep -i "^CodeDirectory" || true)"
entitlements="$(codesign -d --entitlements - "$PLAYER" 2>/dev/null || true)"
is_hardened=0
[[ "$signature" == *runtime* ]] && is_hardened=1
[[ "$signature" != *adhoc* ]] && is_hardened=1

if [[ "$is_hardened" == "1" ]]; then
   um_die "Roblox is still not injectable" "$signature"
fi

# An install another mod re-signed can look injectable on flags alone while
# carrying none of the entitlements the limiter patch needs, so check for the
# entitlements our own re-sign puts on rather than trusting the flags.
for required in allow-dyld-environment-variables disable-executable-page-protection; do
   if [[ "$entitlements" != *"$required"* ]]; then
      um_die "Roblox is missing an entitlement" "$required did not survive the re-sign"
   fi
done

um_good "Verified injectable"

if [[ "$is_modified" == "1" ]]; then
   loaded_us=0
   otool -l "$PLAYER" 2>/dev/null | grep -q "UnlockMetal.dylib" && loaded_us=1

   if [[ "$loaded_us" == "1" ]]; then
      um_good "Patched into the modified Roblox"
   else
      um_die "Injection did not take" "the load command is missing from RobloxPlayer"
   fi

   printf '\n'
   printf '   %s%sReady.%s %sLaunch Roblox the way you always do%s\n' \
      "$UM_BOLD" "$UM_TEXT" "$UM_RESET" "$UM_FAINT" "$UM_RESET"
   printf '   %s(the other mod'\''s launcher, or Roblox itself) and UnlockMetal loads with it.%s\n' \
      "$UM_FAINT" "$UM_RESET"
   printf '   %sUpdating the other mod restores a clean binary - re-run this to re-inject.%s\n\n' \
      "$UM_FAINT" "$UM_RESET"
else
   printf '\n'
   printf '   %s%sReady.%s %sOpen %sUnlockMetal%s%s from Applications to launch.%s\n' \
      "$UM_BOLD" "$UM_TEXT" "$UM_RESET" "$UM_FAINT" "$UM_TEXT" "$UM_RESET" "$UM_FAINT" "$UM_RESET"
   printf '   %sOpening Roblox on its own stays vanilla.%s\n\n' "$UM_FAINT" "$UM_RESET"
fi
