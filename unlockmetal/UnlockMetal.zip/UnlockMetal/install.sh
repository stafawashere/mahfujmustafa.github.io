#!/bin/bash
set -euo pipefail

# Shared terminal styling and the exit hold-open.
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/um_tui.sh"
um_banner "installer"

# Production installer. Ships beside UnlockMetal.app in the release folder and
# installs that exact build onto this machine: copy the app into /Applications,
# clear quarantine, and ad-hoc re-sign Roblox so dyld will honour the insert.
#
#    ./install.sh
#
# Nothing is downloaded and nothing is compiled - what is in the folder is what
# gets installed, so the same folder installs the same build on every Mac.

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DESTINATION_APP="/Applications/UnlockMetal.app"
ROBLOX_APP="${ROBLOX_APP:-/Applications/Roblox.app}"
PLAYER="$ROBLOX_APP/Contents/MacOS/RobloxPlayer"

# The app to install. In a packaged release it sits beside this script; run from
# the dev tree it is wherever the build put it. An explicit path always wins.
find_source_app() {
   local candidates=(
      "$HERE/UnlockMetal.app"
      "$HERE/../obfuscate/dist/UnlockMetal/UnlockMetal.app"
      "$HERE/../dist/UnlockMetal/UnlockMetal.app"
      "$HERE/../dist/UnlockMetal.app"
   )

   for candidate in "${candidates[@]}"; do
      if [[ -d "$candidate" ]]; then
         echo "$candidate"
         return 0
      fi
   done

   return 1
}

if [[ -n "${1:-}" ]]; then
   SOURCE_APP="$1"
else
   SOURCE_APP="$(find_source_app || true)"
fi

architecture="$(arch)"
um_step "Checking hardware"
um_detail "architecture $architecture"

if [[ "$architecture" != "arm64" ]]; then
   um_die "Apple silicon required" "this build is arm64 only"
fi

if [[ -z "$SOURCE_APP" || ! -d "$SOURCE_APP" ]]; then
   um_die "UnlockMetal.app not found" "build it first (./obfuscate/obfuscate.sh) or pass its path"
fi

if [[ ! -x "$PLAYER" ]]; then
   um_die "Roblox is not installed" "install Roblox from roblox.com, then run this again"
fi

um_step "Installing to Applications"
rm -rf "$DESTINATION_APP"
cp -R "$SOURCE_APP" "$DESTINATION_APP"

# A bundle that arrived through a download or an AirDrop carries quarantine and
# other extended attributes; Gatekeeper refuses to run an ad-hoc signed app that
# still has quarantine, and codesign refuses to seal a bundle carrying any xattr
# detritus, so clear them all before signing.
xattr -cr "$DESTINATION_APP" 2>/dev/null || true
codesign -f -s - --deep "$DESTINATION_APP" >/tmp/unlockmetal_install.log 2>&1 \
   || um_die "could not sign the app" "see /tmp/unlockmetal_install.log"

um_step "Preparing Roblox for injection"
ROBLOX_APP="$ROBLOX_APP" "$DESTINATION_APP/Contents/Resources/resign.sh" >/tmp/unlockmetal_install.log 2>&1 \
   || um_die "re-signing failed" "see /tmp/unlockmetal_install.log"

signature="$(codesign -dvv "$PLAYER" 2>&1 | grep -i "^CodeDirectory" || true)"
is_hardened=0
[[ "$signature" == *runtime* ]] && is_hardened=1
[[ "$signature" != *adhoc* ]] && is_hardened=1

if [[ "$is_hardened" == "1" ]]; then
   um_die "Roblox is still not injectable" "$signature"
fi

um_good "Verified injectable"

printf '\n'
printf '   %s%sReady.%s %sOpen %sUnlockMetal%s%s from Applications to launch.%s\n' \
   "$UM_BOLD" "$UM_TEXT" "$UM_RESET" "$UM_FAINT" "$UM_TEXT" "$UM_RESET" "$UM_FAINT" "$UM_RESET"
printf '   %sOpening Roblox on its own stays vanilla.%s\n\n' "$UM_FAINT" "$UM_RESET"
