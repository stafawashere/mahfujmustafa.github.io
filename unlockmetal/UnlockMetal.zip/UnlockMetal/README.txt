UnlockMetal

   1. Install Roblox normally from roblox.com.
   2. Open Terminal in this folder and run:  ./install.sh
   3. Open UnlockMetal from Applications.

Apple silicon only. Opening Roblox itself stays vanilla Roblox.
