#!/bin/bash

# Shared terminal styling for the project's scripts. Source it, then use
# um_banner / um_step / um_detail / um_good / um_warn / um_die. Rich output only
# on a real terminal that has not asked for plain; NO_COLOR, TERM=dumb, a non-tty
# stdout, or UM_PLAIN=1 fall back to pure ASCII so no renderer can choke. Sourcing
# also arms a 10s hold-open on exit, suppressed for nested script calls and for
# non-interactive runs.

# Track nesting so only the outermost script draws a banner and pauses; a script
# this one invokes inherits UM_ACTIVE and stays quiet.
if [[ -z "${UM_ACTIVE:-}" ]]; then
   UM_OUTERMOST=1
   export UM_ACTIVE=1
else
   UM_OUTERMOST=0
fi

um_rich=1
[[ -t 1 ]] || um_rich=0
[[ -n "${NO_COLOR:-}" ]] && um_rich=0
[[ "${TERM:-}" == "dumb" || -z "${TERM:-}" ]] && um_rich=0
[[ "${UM_PLAIN:-}" == "1" ]] && um_rich=0

if [[ "$um_rich" == "1" ]]; then
   UM_FAINT=$'\033[38;5;240m'
   UM_TEXT=$'\033[38;5;253m'
   UM_ACCENT=$'\033[38;5;39m'
   UM_OK=$'\033[38;5;42m'
   UM_WARN=$'\033[38;5;214m'
   UM_BAD=$'\033[38;5;203m'
   UM_BOLD=$'\033[1m'
   UM_RESET=$'\033[0m'
   UM_G_CHECK="$(printf '\342\234\223')"
   UM_G_CROSS="$(printf '\342\234\227')"
   UM_G_WARN="$(printf '\342\232\240')"
   UM_G_DOT="$(printf '\302\267')"
   UM_G_DASH="$(printf '\342\224\200')"
else
   UM_FAINT="" UM_TEXT="" UM_ACCENT="" UM_OK="" UM_WARN="" UM_BAD="" UM_BOLD="" UM_RESET=""
   UM_G_CHECK="ok" UM_G_CROSS="x" UM_G_WARN="!" UM_G_DOT="-" UM_G_DASH="-"
fi

UM_RULE=""
for _ in $(seq 1 36); do UM_RULE="$UM_RULE$UM_G_DASH"; done

um_banner() {
   [[ "$UM_OUTERMOST" == "1" ]] || return 0

   printf '\n'
   printf '   %s%sUNLOCK%s%s%sMETAL%s\n' "$UM_BOLD" "$UM_TEXT" "$UM_RESET" "$UM_BOLD" "$UM_ACCENT" "$UM_RESET"
   printf '   %sframe limiter bypass  %s  %s%s\n' "$UM_FAINT" "$UM_G_DOT" "${1:-}" "$UM_RESET"
   printf '   %s%s%s\n\n' "$UM_FAINT" "$UM_RULE" "$UM_RESET"
}

um_step() {
   printf '   %s%s%s %s%s%s\n' "$UM_ACCENT" "$UM_G_DOT" "$UM_RESET" "$UM_TEXT" "$1" "$UM_RESET"
}

um_detail() {
   printf '     %s%s%s\n' "$UM_FAINT" "$1" "$UM_RESET"
}

um_good() {
   printf '   %s%s%s %s%s%s\n' "$UM_OK" "$UM_G_CHECK" "$UM_RESET" "$UM_TEXT" "$1" "$UM_RESET"
}

um_warn() {
   printf '   %s%s%s %s%s%s\n' "$UM_WARN" "$UM_G_WARN" "$UM_RESET" "$UM_TEXT" "$1" "$UM_RESET"
}

um_die() {
   printf '   %s%s%s %s%s%s\n' "$UM_BAD" "$UM_G_CROSS" "$UM_RESET" "$UM_TEXT" "$1" "$UM_RESET" >&2
   [[ -n "${2:-}" ]] && printf '     %s%s%s\n' "$UM_FAINT" "$2" "$UM_RESET" >&2
   exit 1
}

if [[ -t 1 && "$UM_OUTERMOST" == "1" ]]; then
   trap 'printf "\n   %sclosing in 10s...%s\n" "$UM_FAINT" "$UM_RESET" >/dev/tty 2>&1 || true; sleep 10 || true' EXIT
fi
