#!/bin/bash
set -euo pipefail

# Persistently inject UnlockMetal into a Roblox that another mod already owns.
# The dylib is copied beside RobloxPlayer and a weak load command is patched into
# the binary, so UnlockMetal loads on every launch no matter who starts the game
# - the mod's own launcher, Roblox.app, or anything else - and always against
# whatever client version that launcher is running. Re-running is safe: the patch
# is idempotent and the copy just refreshes.
#
# Everything this needs sits beside it (um_patch, the dylib, resign.sh); a dev
# tree can point INJECT_DYLIB / UM_PATCH elsewhere.

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="${ROBLOX_APP:-/Applications/Roblox.app}"
MACOS="$APP/Contents/MacOS"
PLAYER="$MACOS/RobloxPlayer"
DEST="$MACOS/UnlockMetal.dylib"

UM_PATCH="${UM_PATCH:-$HERE/um_patch}"
DYLIB="${INJECT_DYLIB:-$HERE/UnlockMetal.dylib}"
RESIGN="${UM_RESIGN:-$HERE/resign.sh}"

if [[ ! -x "$PLAYER" ]]; then
   echo "error: RobloxPlayer not found at $PLAYER" >&2
   exit 1
fi

if [[ ! -f "$DYLIB" ]]; then
   echo "error: UnlockMetal.dylib not found at $DYLIB" >&2
   exit 1
fi

if [[ ! -x "$UM_PATCH" ]]; then
   echo "error: um_patch not found at $UM_PATCH" >&2
   exit 1
fi

cp -f "$DYLIB" "$DEST"

# um_patch exits 0 when it adds the load command and 2 when the binary already
# carries it; both mean the seal below is what makes it live.
set +e
"$UM_PATCH" "$PLAYER" "@executable_path/UnlockMetal.dylib"
patch_rc=$?
set -e

if [[ "$patch_rc" != "0" && "$patch_rc" != "2" ]]; then
   echo "error: um_patch failed ($patch_rc)" >&2
   exit 1
fi

ROBLOX_APP="$APP" "$RESIGN"
