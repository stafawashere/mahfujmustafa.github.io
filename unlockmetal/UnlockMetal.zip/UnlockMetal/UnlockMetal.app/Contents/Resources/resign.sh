#!/bin/bash
set -euo pipefail

# Re-sign /Applications/Roblox.app so a foreign, ad-hoc-signed dylib can be
# inserted via DYLD_INSERT_LIBRARIES. Repeatable after every Roblox update, and
# shape-agnostic: an install another mod has already rearranged signs the same
# way a stock one does, because everything below is discovered rather than named.
#
# Approach: ad-hoc re-sign inside-out, DROPPING the hardened runtime flag.
# Rationale is in SIGNING-NOTES.md. Short version:
#   - Hardened runtime implies library validation, which rejects our foreign
#     dylib. Dropping the runtime removes that gate.
#   - DYLD_* env vars are ignored by dyld for a "restricted" (hardened +
#     Developer-ID, no get-task-allow) main executable. Re-signing ad-hoc with
#     get-task-allow + allow-dyld-environment-variables makes them honored.
#   - Inside-out order: nested Mach-O first (mimalloc, helpers, embedded apps),
#     then the main executable last, so the bundle's seal is internally
#     consistent.

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="${ROBLOX_APP:-/Applications/Roblox.app}"
MACOS="$APP/Contents/MacOS"
ENTS="$HERE/entitlements.plist"
IDENTITY="-"   # ad-hoc

if [[ ! -d "$APP" ]]; then
   echo "error: $APP not found" >&2
   exit 1
fi

if [[ ! -f "$ENTS" ]]; then
   echo "error: entitlements plist missing at $ENTS" >&2
   exit 1
fi

is_mach_o() {
   [[ -f "$1" ]] || return 1

   file -b "$1" 2>/dev/null | grep -q "Mach-O"
}

is_bundle_dir() {
   case "$1" in
      *.app|*.framework|*.bundle|*.xpc) return 0 ;;
      *) return 1 ;;
   esac
}

sign_one() {
   local target="$1"
   local with_ents="$2"

   if [[ "$with_ents" == "ents" ]]; then
      codesign --force --sign "$IDENTITY" --entitlements "$ENTS" \
         --timestamp=none "$target"
   else
      codesign --force --sign "$IDENTITY" --timestamp=none "$target"
   fi
}

# Loose Mach-O anywhere under Contents that is not the main executable and does
# not live inside an embedded bundle (those are sealed with their own bundle).
# A mod that dropped its dylib beside RobloxPlayer is picked up here without
# this script having to know its name.
loose_mach_o() {
   while IFS= read -r -d '' candidate; do
      [[ "$candidate" == "$MACOS/RobloxPlayer" ]] && continue

      # Match on the path inside the bundle, so a Roblox.app sitting under some
      # other .app directory does not exclude everything in it.
      case "${candidate#"$APP/"}" in
         *.app/*|*.framework/*|*.bundle/*|*.xpc/*) continue ;;
      esac

      is_mach_o "$candidate" || continue

      printf '%s\n' "$candidate"
   done < <(find "$APP/Contents" -type f -print0 2>/dev/null)
}

# Embedded bundles, deepest first, so a nested one is sealed before whatever
# contains it. Stock Roblox has RobloxMenuBar.app and RobloxPlayerInstaller.app;
# a modified install may be missing either, or carry extras.
embedded_bundles() {
   while IFS= read -r -d '' bundle; do
      depth="$(printf '%s' "$bundle" | tr -cd '/' | wc -c | tr -d ' ')"
      printf '%s\t%s\n' "$depth" "$bundle"
   done < <(find "$APP/Contents" \( -name "*.app" -o -name "*.framework" -o -name "*.bundle" -o -name "*.xpc" \) -print0 2>/dev/null) \
      | sort -rn | cut -f2-
}

echo "==> Re-signing loose Mach-O (inside-out)"

# Nested dylibs and helper executables. Signed without hardened runtime; no
# entitlements needed on these - they just have to carry a valid ad-hoc seal
# under the same (library-validation-free) main binary.
while IFS= read -r nested; do
   [[ -n "$nested" ]] || continue
   echo "    $nested"

   if ! sign_one "$nested" noents; then
      echo "error: failed to sign $nested" >&2
      exit 1
   fi
done < <(loose_mach_o)

echo "==> Re-signing embedded bundles"
while IFS= read -r embedded; do
   [[ -n "$embedded" ]] || continue
   echo "    $embedded"

   # Sign the bundle's own Mach-O first, then the bundle itself. Process
   # substitution keeps the loop in this shell so a nested sign failure can
   # abort loudly instead of being lost in a pipe subshell.
   while IFS= read -r -d '' bin; do
      is_mach_o "$bin" || continue

      if ! sign_one "$bin" noents; then
         echo "error: failed to sign nested binary $bin" >&2
         exit 1
      fi
   done < <(find "$embedded" -type f -print0 2>/dev/null)

   sign_one "$embedded" noents
done < <(embedded_bundles)

echo "==> Re-signing whole bundle (last, with entitlements)"

# codesign refuses to seal a bundle that has non-Mach-O files sitting directly
# in Contents/MacOS. Roblox's runtime-generated ClientSettings/ FastFlags dir is
# one, and a modified install usually leaves its own config or payload there
# too, so everything in there that is neither code nor a bundle gets stashed
# aside for the duration of the bundle sign and put back after.
STASH_DIR="$(mktemp -d)"
STASHED=()
while IFS= read -r -d '' extra; do
   is_bundle_dir "$extra" && continue
   is_mach_o "$extra" && continue

   mv "$extra" "$STASH_DIR/$(basename "$extra")"
   STASHED+=("$extra")
done < <(find "$MACOS" -mindepth 1 -maxdepth 1 -print0 2>/dev/null)

restore_stash() {
   for extra in "${STASHED[@]:-}"; do
      [[ -n "$extra" ]] || continue
      mv "$STASH_DIR/$(basename "$extra")" "$extra"
   done
   rmdir "$STASH_DIR" 2>/dev/null || true
}

trap restore_stash EXIT

if [[ "${#STASHED[@]}" -gt 0 ]]; then
   echo "    stashed while sealing: ${STASHED[*]##*/}"
fi

codesign --force --sign "$IDENTITY" --entitlements "$ENTS" \
   --timestamp=none "$APP"

# Verify while the stashed files are still out, so the bundle seal is clean.
# ClientAppSettings.json is written back into the bundle after this (by the
# launcher, and by Roblox at runtime); the kernel validates only the main
# executable's own signature at launch, not the resource seal, so an added
# ClientSettings file does not block injection - but it would fail a strict
# verify, which is why the check runs here rather than after the restore.
echo "==> Verifying"
codesign --verify --verbose=2 "$MACOS/RobloxPlayer"

restore_stash
trap - EXIT

echo "--- entitlements now on RobloxPlayer ---"
codesign -d --entitlements - --xml "$MACOS/RobloxPlayer" 2>/dev/null \
   | plutil -convert xml1 -o - - 2>/dev/null || \
   codesign -d --entitlements - "$MACOS/RobloxPlayer" 2>&1 | tail -1
echo "--- signature flags (expect NO 'runtime') ---"
codesign -dvv "$MACOS/RobloxPlayer" 2>&1 | grep -iE "flags|Signature"

echo "==> Done."
