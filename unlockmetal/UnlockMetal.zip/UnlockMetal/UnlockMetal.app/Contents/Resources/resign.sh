#!/bin/bash
set -euo pipefail

# Re-sign /Applications/Roblox.app so a foreign, ad-hoc-signed dylib can be
# inserted via DYLD_INSERT_LIBRARIES. Repeatable after every Roblox update.
#
# Approach: ad-hoc re-sign inside-out, DROPPING the hardened runtime flag.
# Rationale is in SIGNING-NOTES.md. Short version:
#   - Hardened runtime implies library validation, which rejects our foreign
#     dylib. Dropping the runtime removes that gate.
#   - DYLD_* env vars are ignored by dyld for a "restricted" (hardened +
#     Developer-ID, no get-task-allow) main executable. Re-signing ad-hoc with
#     get-task-allow + allow-dyld-environment-variables makes them honored.
#   - Inside-out order: nested Mach-O first (mimalloc, helpers, embedded apps),
#     then the main executable last, so the bundle's seal is internally
#     consistent.

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP="${ROBLOX_APP:-/Applications/Roblox.app}"
MACOS="$APP/Contents/MacOS"
ENTS="$HERE/entitlements.plist"
IDENTITY="-"   # ad-hoc

if [[ ! -d "$APP" ]]; then
   echo "error: $APP not found" >&2
   exit 1
fi

if [[ ! -f "$ENTS" ]]; then
   echo "error: entitlements plist missing at $ENTS" >&2
   exit 1
fi

sign_one() {
   local target="$1"
   local with_ents="$2"

   if [[ "$with_ents" == "ents" ]]; then
      codesign --force --sign "$IDENTITY" --entitlements "$ENTS" \
         --timestamp=none "$target"
   else
      codesign --force --sign "$IDENTITY" --timestamp=none "$target"
   fi
}

echo "==> Re-signing nested Mach-O (inside-out)"

# Nested dylibs and helper executables. Signed without hardened runtime; no
# entitlements needed on these — they just have to carry a valid ad-hoc seal
# under the same (library-validation-free) main binary.
for nested in \
   "$MACOS/libmimalloc.3.dylib" \
   "$MACOS/RobloxCrashHandler"
do
   if [[ -e "$nested" ]]; then
      echo "    $nested"
      sign_one "$nested" noents
   fi
done

echo "==> Re-signing embedded .app bundles"
for embedded in "$MACOS/RobloxMenuBar.app" "$MACOS/RobloxPlayerInstaller.app"; do
   if [[ -d "$embedded" ]]; then
      echo "    $embedded"
      # Sign the embedded bundle's own main executable, then the bundle.
      # Process substitution keeps the loop in this shell so a nested sign
      # failure can abort loudly instead of being lost in a pipe subshell.
      while IFS= read -r -d '' bin; do
         if ! sign_one "$bin" noents; then
            echo "error: failed to sign nested binary $bin" >&2
            exit 1
         fi
      done < <(find "$embedded/Contents/MacOS" -type f -perm +111 -print0 2>/dev/null)
      sign_one "$embedded" noents
   fi
done

echo "==> Re-signing whole bundle (last, with entitlements)"

# codesign refuses to seal a bundle that has non-Mach-O files inside
# Contents/MacOS (Roblox's runtime-generated ClientSettings/ FastFlags dir is
# one). Stash any such dirs aside for the duration of the bundle sign, then put
# them back. The kernel loader validates only the main executable's own
# signature at launch, not the resource seal, so a non-deep seal is fine here.
STASH_DIR="$(mktemp -d)"
STASHED=()
for extra in "$MACOS/ClientSettings"; do
   if [[ -e "$extra" ]]; then
      mv "$extra" "$STASH_DIR/$(basename "$extra")"
      STASHED+=("$extra")
   fi
done

restore_stash() {
   for extra in "${STASHED[@]:-}"; do
      [[ -n "$extra" ]] || continue
      mv "$STASH_DIR/$(basename "$extra")" "$extra"
   done
   rmdir "$STASH_DIR" 2>/dev/null || true
}
trap restore_stash EXIT

codesign --force --sign "$IDENTITY" --entitlements "$ENTS" \
   --timestamp=none "$APP"

restore_stash
trap - EXIT

echo "==> Verifying"
codesign --verify --verbose=2 "$MACOS/RobloxPlayer"
echo "--- entitlements now on RobloxPlayer ---"
codesign -d --entitlements - --xml "$MACOS/RobloxPlayer" 2>/dev/null \
   | plutil -convert xml1 -o - - 2>/dev/null || \
   codesign -d --entitlements - "$MACOS/RobloxPlayer" 2>&1 | tail -1
echo "--- signature flags (expect NO 'runtime') ---"
codesign -dvv "$MACOS/RobloxPlayer" 2>&1 | grep -iE "flags|Signature"

echo "==> Done."
